package Surepay_TestPage_Test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import BaseClass.BaseClass;
import CommonFunctions.CommonFunctions;
import SurepayTestData.SurepayTestData;
import Surepay_TestPage_Action.Surepay_PayPage_Action;
import Surepay_TestPage_Action.Surepay_Razorpay_Action;
import Surepay_TestPage_Action.Surepay_ResponsePage_Action;
import Surepay_TestPage_Action.Surepay_TestPage_Action;

public class Surepay_TestPage_Test extends BaseClass

{
	Surepay_TestPage_Action SurepayTPA;
	Surepay_PayPage_Action SurepayPPA;
	Surepay_Razorpay_Action SurepayRPA;
	Surepay_ResponsePage_Action SurepayResPL;

	@Test(dataProvider ="TransactionData", dataProviderClass = SurepayTestData.class)
	public void Transaction(String merchantID, String serviceID, String customerID, String TxnAmt, String channelmode, String entity, String Number, String Month, String Year, String HolderName, String CVV, String status) throws IOException, InterruptedException, SQLException
	{
		SurepayTPA=new Surepay_TestPage_Action(dr,logger);
		SurepayPPA=new Surepay_PayPage_Action(dr,logger);
		SurepayRPA=new Surepay_Razorpay_Action(dr,logger);
		SurepayResPL=new Surepay_ResponsePage_Action(dr, logger);
		
		SurepayTPA.fillDetails(merchantID, serviceID, customerID, TxnAmt);
		SurepayPPA.pay(channelmode, entity,Number, Month, Year, HolderName, CVV);
		Thread.sleep(9000);
		SurepayRPA.RazorpayStatusPage(status);
		Thread.sleep(9000);
		String bankRef=SurepayResPL.getB2BResponse();
		Thread.sleep(9000);
		//DBConnection(SurepayResPL.getTransactionDetails()); //Way -1 
		//TransactionMaster("txn_sp_payment_transaction", "spt_txn_id", "spt_transaction_status", "spt_surepay_mid", "spt_bank_ref_code", "spt_bank_ref_code",SurepayResPL.getTransactionDetails()); //Way-2

		List<String> columns=CommonFunctions.fetchTableAttributes("spt_txn_id","spt_transaction_status", "spt_surepay_mid", "spt_bank_ref_code", "spt_merchant_order_id");
		CommonFunctions.fetchQueryData("txn_sp_payment_transaction", columns, "spt_bank_ref_code", bankRef,logger);//Way - 3
		
		logger.log(LogStatus.PASS, logger.addScreenCapture(screenshot(dr, "TC_01")));
	}
}
