package CommonFunctions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import jdk.jfr.internal.Logger;

public class CommonFunctions 
{
	
	public static void selectElement(WebDriver dr, ExtentTest logger, WebElement webEle, String selectValue, String fieldname)
	{
		try
		{
			WebDriverWait wt=new WebDriverWait(dr, Duration.ofSeconds(10));
		
		WebElement elementchecked=wt.until(ExpectedConditions.elementToBeClickable(webEle));
		Select sel=new Select(webEle);
		sel.selectByValue(selectValue);
		logger.log(LogStatus.PASS, fieldname+ " is selected");
		}
		catch(Exception e)
		{
			logger.log(LogStatus.FAIL, e.getMessage());
		}
	}
	
	public static void enterText(WebDriver dr, ExtentTest logger, WebElement webEle, String Value,String fieldname)
	{
		try
		{
		WebDriverWait wt=new WebDriverWait(dr, Duration.ofSeconds(10));
		WebElement elementPresent=wt.until(ExpectedConditions.visibilityOf(webEle));
		elementPresent.sendKeys(Value);
		logger.log(LogStatus.PASS, fieldname+ " is entered");
		}
		catch(Exception e)
		{
			logger.log(LogStatus.FAIL, "Occured some Error"+fieldname+ "is not selected");
		}
		
	}
	
	public static void click(WebDriver dr, ExtentTest logger, WebElement webEle, String fieldname)
	{
		try {
			WebDriverWait wt=new WebDriverWait(dr,Duration.ofSeconds(10));
			WebElement elementClicable=wt.until(ExpectedConditions.elementToBeClickable(webEle));
			elementClicable.click();
			logger.log(LogStatus.PASS, fieldname+" is clicked");
		} 
		
		catch (Exception e) 
		{
			logger.log(LogStatus.FAIL, e.getMessage());
		}
	}
	
	public static void selectDropDown(WebElement selDrop, String selValue, String fieldName, ExtentTest logger)
	{
		try
		{
		Select sel=new Select(selDrop);
		sel.selectByValue(selValue);
		logger.log(LogStatus.PASS, fieldName+" is selected");
		}
		catch (Exception e)
		{
			logger.log(LogStatus.FAIL, e.getMessage());
		}
		
	}
	
	private static final String URL = "jdbc:postgresql://10.250.10.241:5432/SUREPAYDB-PROD";
    private static final String USER = "SureAdmin";
    private  static final String PASSWORD = "ndml@1234";
	
	public static void DBConnection(String bankRefCode) throws SQLException
	{
	   String query="Select spt_txn_id,spt_transaction_status,spt_surepay_mid,spt_bank_ref_code from txn_sp_payment_transaction where spt_bank_ref_code=?";
	   	
	       Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	             PreparedStatement stmt = conn.prepareStatement(query);
	             stmt.setString(1,bankRefCode);
	             ResultSet rs = stmt.executeQuery();
	             
	           while(rs.next())
	           {
	        	   String txn_id=rs.getString("spt_txn_id");
	        	   String txn_status=rs.getString("spt_transaction_status");
	        	   String surepay_mid=rs.getString("spt_surepay_mid");
	        	   String bank_ref_code=rs.getString("spt_bank_ref_code");

	        	   System.out.println(txn_id);
	        	   System.out.println(txn_status);
	        	   System.out.println(surepay_mid);
	        	   System.out.println(bank_ref_code);
	           }
	}
	
	public static void TransactionMaster(String table_name,String txn_id, String transaction_status, String surepay_mid, String bankRefCode, String whereCols, String whereValue) throws SQLException
	{
	   String query="Select "+txn_id+","+transaction_status+","+surepay_mid+","+bankRefCode+" from "+table_name+" where "+whereCols+" =?";
	   	
	   //String query="Select spt_txn_id,spt_transaction_status,spt_surepay_mid,spt_bank_ref_code from txn_sp_payment_transaction where spt_bank_ref_code=?";

	       Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	             PreparedStatement stmt = conn.prepareStatement(query);
	             stmt.setString(1,whereValue);
	             ResultSet rs = stmt.executeQuery();
	             
	           while(rs.next())
	           {
	        	   String txnId=rs.getString("spt_txn_id");
	        	   String txn_status=rs.getString("spt_transaction_status");
	        	   String surepayMid=rs.getString("spt_surepay_mid");
	        	   String bankrefcode=rs.getString("spt_bank_ref_code");

	        	   System.out.println(txnId);
	        	   System.out.println(txn_status);
	        	   System.out.println(surepayMid);
	        	   System.out.println(bankrefcode);
	           }
	}
	
	public static List<String> fetchTableAttributes(String col1, String col2,String col3, String col4, String col5)
	{
		List<String> columns=Arrays.asList(col1,col2,col3,col4,col5);
		return columns;
	}
	
	public static void fetchQueryData(String tableName, List<String> colNames, String whereColName, String whereValue, ExtentTest logger) throws SQLException
	{
		String colsJoined=String.join(",", colNames);
		String query="Select "+colsJoined+" from "+tableName+" Where "+whereColName+"= ?";
		try
		{
		Connection con=DriverManager.getConnection(URL,USER,PASSWORD);
		PreparedStatement state=con.prepareStatement(query);
		state.setString(1, whereValue);
		ResultSet rs=state.executeQuery();
		while(rs.next())
		{
			for(String col:colNames)
			{
				String attributeName=rs.getString(col);
				System.out.println(col+" -> "+attributeName);
				logger.log(LogStatus.PASS, col+" -> "+attributeName);
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}
