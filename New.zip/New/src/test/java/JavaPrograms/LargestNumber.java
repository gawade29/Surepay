package JavaPrograms;

public class LargestNumber {

	public static void main(String[] args) {
		
		int[] num= {100,200,50};
		
		int max=num[0];// consider this is the max no at '0' index
		
		for(int i=1; i<num.length;i++) //start loop with '1' index
		{
			if(num[i]>max) //it check array values with max, if condition is matched, then update the value of max
			{
				max=num[i];
			}
		}
		System.out.println(max);
		
		int[] numbers = {45, 22, 89, 105, 67};

		int largest = Integer.MIN_VALUE;
		int secondLargest = Integer.MIN_VALUE;
		
		System.out.println(largest);
		System.out.println(secondLargest);

	}

}
