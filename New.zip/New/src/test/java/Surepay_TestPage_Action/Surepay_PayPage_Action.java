package Surepay_TestPage_Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import CommonFunctions.CommonFunctions;
import Surepay_TestPage_Locator.Sureay_PayPage_Locator;
import lombok.AllArgsConstructor;

public class Surepay_PayPage_Action 
{
	public static WebDriver driver;
	public static ExtentTest logger;
	public static Sureay_PayPage_Locator SurepayPPL;
	
	public Surepay_PayPage_Action(WebDriver dr, ExtentTest logger)
	{
		Surepay_PayPage_Action.driver=dr;
		Surepay_PayPage_Action.logger=logger;
		SurepayPPL=new Sureay_PayPage_Locator(dr,logger);
	}
	
	public static void selectChannelCodeWithEntity(String channelMode, String entity, String Number, String Month, String Year, String HolderName, String CVV)
	{
		WebElement PaymentMode;
		switch(channelMode)
		{
		case "IBANK":
			PaymentMode=SurepayPPL.getNetBanking();
			CommonFunctions.click(driver, logger, PaymentMode, "Payment Mode-IBANK");
			selectBanks(entity);
			break;
			
		case "DDCARD":
			PaymentMode=SurepayPPL.getDebitCard();
			CommonFunctions.click(driver, logger, PaymentMode, "Payment Mode-DDCARD");
			EnterCardDetails(Number, Month, Year, HolderName, CVV);
			break;
			
		case "DCCARD":
			PaymentMode=SurepayPPL.getCreditCard();
			CommonFunctions.click(driver, logger, PaymentMode, "Payment Mode-DCCARD");
			EnterCardDetails(Number, Month, Year, HolderName, CVV);
			break;
			
		case "WALLET":
			PaymentMode=SurepayPPL.getWallet();
			CommonFunctions.click(driver, logger, PaymentMode, "Payment Mode-IBANK");
			selectWallets(entity);
			break;
			
		default: 
			logger.log(LogStatus.ERROR, "Invalid Channelmode is selected");
		}
	}
	
	public static void selectBanks(String entity)
	{
		WebElement paymentEntity;
		switch(entity)
		{
			case "ICICI":
			paymentEntity=SurepayPPL.getICICIBank(); 
			CommonFunctions.click(driver, logger, paymentEntity, "ICICI-Bank");
			break;
			
			case "HDFC":
			paymentEntity=SurepayPPL.getHDFCBank(); 
			CommonFunctions.click(driver, logger, paymentEntity, "HDFC-Bank");
			
			default:
			logger.log(LogStatus.ERROR, "Invalid Bank Entity is selected");		
		}
	}
	public static void selectWallets(String entity)
	{
		WebElement paymentEntity;
		switch(entity)
		{
			case "mobikwik":
			paymentEntity=SurepayPPL.getMobikwik(); 
			CommonFunctions.click(driver, logger, paymentEntity, "Mobikwik-WAllet");
			break;
			
			case "amazonpay":
			paymentEntity=SurepayPPL.getHDFCBank(); 
			CommonFunctions.click(driver, logger, paymentEntity, "Amazonpay-Wallet");
			
			default:
			logger.log(LogStatus.ERROR, "Invalid Wallet is selected");		
		}
	}
		
		public static void pay(String channelMode, String entity,String Number, String Month, String Year, String HolderName, String CVV)
		{
			selectChannelCodeWithEntity(channelMode,entity,Number, Month, Year, HolderName, CVV);
			WebElement pay=SurepayPPL.getPayNow();
			CommonFunctions.click(driver, logger, pay, "PayButton");
		}
	
	
	public static void EnterCardDetails(String Number, String Month, String Year, String HolderName, String CVV)
	{
		WebElement cardNum=SurepayPPL.getCardNumber();
		CommonFunctions.enterText(driver,logger,cardNum,Number,"CARD NUMBER");
		
		WebElement cardMonth=SurepayPPL.getCardValidityMonth();
		CommonFunctions.selectDropDown(cardMonth, Month, "CARD MONTH", logger);
		
		WebElement cardYear=SurepayPPL.getCardValidityYear();
		CommonFunctions.selectDropDown(cardYear, Year, "CARD YEAR", logger);
		
		WebElement cardHolderName=SurepayPPL.getCardHolderName();
		CommonFunctions.enterText(driver,logger,cardHolderName,HolderName,"CARD HOLDER NAME");
		
		WebElement cardCVV=SurepayPPL.getCardCVV();
		CommonFunctions.enterText(driver,logger,cardCVV,CVV,"CARD CVV");
	}
	
}
