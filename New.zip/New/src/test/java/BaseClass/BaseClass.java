package BaseClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BaseClass 
{
	public static WebDriver dr=null;
	public static ExtentReports extentReport=null;
	public static ExtentTest logger=null;
	public static String path="C:\\Users\\Swapnali.Gavade\\SurepayResult.html";
	public static String Screenshot_path="C:\\Users\\Swapnali.Gavade\\";
	
	@BeforeSuite
	public void beforeSuite() throws IOException
	{
		extentReport=new ExtentReports(path,true);// it concatenates the file path(test Report) and file name and creates final file name.
	}
	 
	@BeforeMethod
	public void beforeMethod(Method testMethodName, Object[] readMultipleTestData) throws IOException
	{
	logger=extentReport.startTest(testMethodName.getName());
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Swapnali.Gavade\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");

	dr=new ChromeDriver();
	dr.manage().window().maximize();
	dr.get("https://pilot.surepay.ndml.in/SurePayPayment/testMerchantPage");
	}
	 
	@AfterMethod
	public void afterMethod() throws IOException, InterruptedException
	{
		extentReport.endTest(logger);
		dr.quit();
	}
	
	@AfterSuite
	public void afterSuite()
	{
		extentReport.flush();
	}
	
	public static String screenshot(WebDriver dr, String ScreenshotName) throws IOException
	{
		String timestamp = new SimpleDateFormat("ddMMyyHHmmss").format(new Date());
		TakesScreenshot takeSs=(TakesScreenshot)dr; //driver takes control to capture SS of website
		File opFile=takeSs.getScreenshotAs(OutputType.FILE); // it defines the format of output type
		File dest= new File(".//ScreenShots//"+ScreenshotName+timestamp+".png"); // it defines on which destination file will gets saved along with SS Name
		FileUtils.copyFile(opFile, dest);// it copies the created output file to destination path
		return dest.getAbsolutePath();
	}
	
}
