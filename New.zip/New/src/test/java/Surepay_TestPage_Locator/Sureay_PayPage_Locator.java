package Surepay_TestPage_Locator;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;

import lombok.Data;
@Data
public class Sureay_PayPage_Locator 
{

	public static WebDriver driver;
	public static ExtentTest logger;
	
	public Sureay_PayPage_Locator(WebDriver dr, ExtentTest logger)
	{
		this.driver=dr;
		this.logger=logger;
		PageFactory.initElements(dr, this);
	}
	
	//All Channel codes
	@FindBy(xpath="//label[@id='channelCodelabel' and normalize-space(text())='Net Banking']") private WebElement NetBanking;
	@FindBy(xpath="//label[@id='channelCodelabel' and normalize-space()='Debit Card']") private WebElement DebitCard;
	@FindBy(xpath="//label[@id='channelCodelabel' and normalize-space()='Credit Card']") private WebElement CreditCard; 
	@FindBy(xpath="//label[@id='channelCodelabel' and normalize-space(text())='Wallet']") private WebElement Wallet;
	
	//All Entities under IBANK
	@FindBy(xpath="//div[@id='ICIC']") private WebElement ICICIBank;
	@FindBy(xpath="//div[@id='INDB']") private WebElement IndusindBank;
	@FindBy(xpath="//div[@id='HDFC']") private WebElement HDFCBank;
	@FindBy(xpath="//div[@id='STXB']") private WebElement SutexBank;
	
	//All entities under Wallet
	@FindBy(xpath="//div[@id='mobikwik']") private WebElement mobikwik;
	@FindBy(xpath="//div[@id='amazonpay']") private WebElement amazonpay;
	
	//Enter card details
	@FindBy(xpath="//input[@formcontrolname='cardNumber']") private WebElement CardNumber;
	@FindBy(xpath="//select[@id='dropdowncss' and @formcontrolname='month']") private WebElement cardValidityMonth;
	@FindBy(xpath="//select[@id='dropdowncss' and @formcontrolname='year']") private WebElement cardValidityYear;
	@FindBy(xpath="//input[@formcontrolname='cardName']") private WebElement cardHolderName;
	@FindBy(xpath="//input[@id='cvv']") private WebElement cardCVV;

	//Click on Pay button
	@FindBy(xpath="//*[text()='Pay Now']") public WebElement PayNow;
}
