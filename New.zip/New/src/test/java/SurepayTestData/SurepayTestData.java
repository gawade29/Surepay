package SurepayTestData;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class SurepayTestData
{

	public XSSFWorkbook workbook;
	public XSSFSheet sheet;
	public XSSFRow readRow;
	public XSSFCell readCell;
	public void setExcelFile(String fileName, String SheetName) throws IOException	// Set excel file path
	{
		FileInputStream excelFile=new FileInputStream(fileName);
		workbook=new XSSFWorkbook(excelFile);
		sheet=workbook.getSheet(SheetName);
	}

	public Object[][] readMultipleTestfile(String fileName, String SheetName) throws IOException		// To read multiple records from excel
	{
		setExcelFile(fileName,SheetName);
		int totalRow=sheet.getPhysicalNumberOfRows();		// Total no of rows
		//int totalRow=sheet.getLastRowNum()+1;		// Total no of rows

		int totalCols=sheet.getRow(0).getPhysicalNumberOfCells();//Total no of columns in one row
		//int totalCols=sheet.getRow(0).getLastCellNum();//Total no of columns in one row

		System.out.println("Total row"+ totalRow);
		System.out.println("Total cols"+totalCols);
		Object[][] data=new Object[totalRow][totalCols];	// created 2 dimensional array of Data
		
		for(int i=0; i<totalRow; i++)
		{
			XSSFRow readRow=sheet.getRow(i);
			
			for(int j=0;j<totalCols;j++)
			{
				XSSFCell readCell=readRow.getCell(j);
				DataFormatter format=new DataFormatter();
				String cellVal=format.formatCellValue(readCell);
				data[i][j]=cellVal;
			}
		}
		return data;
				
	}
	
	@DataProvider(name="TransactionData")
	public Object readMultipleTestData() throws IOException
	{
		Object[][] data=readMultipleTestfile("C:\\Users\\Swapnali.Gavade\\Documents\\IBank-TestData.xlsx","TC");
		return data;
	}
	
}
